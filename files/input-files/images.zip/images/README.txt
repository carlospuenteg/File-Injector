You were able to decrypt this, since it was encrypted using the default decryption key: "h8SiovDB5Yz3zX9y2O1MTAUfoCfAPTFWbRBupuYg2zg"

If you delete it from the "files/$encryption-keys" folder, you won't be able to decrypt it.

You can see that the image 1'7MP.png has been extracted from... itself?. How is it possible?